//let btnLoguin = document.getElementById("btn-loguin");

//btnLoguin.addEventListener("click", function() {
//   Aplicar la animación al botón
// this.style.animation = "animacionBoton  animation-duration: 5s";
 // Cambiar el texto del botón
// btnLoguin.innerHTML = "Redirigiendo...";
 //console.log(this.click.target.addEventListener);
// Después de que termine la animación, redirigir al enlace
// setTimeout(function() {
//    window.location.href = './loading.html';
//}, 2000);

//});
// Obtener referencias a elementos HTML
//let mostrarConfetiBtn = document.getElementById("btn-loguin");
//let contenedorConfeti = document.getElementById("contenedorConfeti");

// Función para crear y mostrar confetis


 // function mostrarConfetis() {
 //   for (let i = 0; i < 20; i++) { // creo 20 confetis
 //       let confeti = document.createElement("div");
 //       confeti.classList.add("confeti");
//        contenedorConfeti.appendChild(confeti);

        // Establece posiciones aleatorias para los confetis
 //       const randomX = Math.random() * window.innerWidth;
 //       const randomY = Math.random() * window.innerHeight;
 //       confeti.style.left = randomX + "px";
 //       confeti.style.top = randomY + "px";
//    }
 //   contenedorConfeti.style.display = "flex"; // Mostrar el contenedor
//}

// Agregar un manejador de eventos al botón "Mostrar Confeti"
//mostrarConfetiBtn.addEventListener("click", function() {
 //   mostrarConfetis();

    // Después de 5 segundos, redirigir a la página de "Loading"
 //   setTimeout(function() {
 //       window.location.href = "loading.html"; // me redirige a mi página de loading
//    }, 3000); // Duración de la animación de confeti (en milisegundos)
//});


