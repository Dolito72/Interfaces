/*
document.addEventListener("DOMContentLoaded", function (event) {
    // Oculta el canvas-container al cargar la página

   // document.querySelector('.ocultarCanvas').classList.add('ocultar');


  document.querySelector('#btn-juego').addEventListener('click', function () {
        // Oculta el contenido actual
        document.querySelector('#img-juego').style.display = 'none';
        document.querySelector('#game-settings').style.display = 'none';

        // Muestra el canvas-container
        document.querySelector('.ocultarCanvas').style.display = 'block';

        // Establece los eventos para los botones
        setFormBtnsEvents();
    });







});*/