
Enunciado: https://docs.google.com/document/d/19b8KNL0eUT8FDL2u4s1yE7fpuORO5-2Wked4P0Gxs_g/edit#heading=h.6h2hkq8zgdsc


La resolucion del mobile first, se aplicó sobre el modelo de dispositivo Iphone 12 Pro, con una resolucion de 390 px de ancho.

Las correciones fueron aplicadas a saber:

- Ancho de la página en modo desktop
- Ancho de la página en mobile
- Menu hamburguesa
- Animación: la misma se aplicó al primer carrusel, el cual tiene un scroll automático y se detiene cuando se posiciona el cursor por encima.


